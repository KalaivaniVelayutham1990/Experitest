"use strict";
var webdriverio = require('webdriverio');

function main() {

  let options = {
    host: 'rbc.experitest.com',
    protocol: 'https',
    port: 443,
    path: '/wd/hub',  
    desiredCapabilities: {
        browserName: 'chrome',
        accessKey: "eyJhbGciOiJIUzI1NiJ9.eyJ4cC51IjoxMjU0NjIwLCJ4cC5wIjoxMjA3MDA1LCJ4cC5tIjoxNjAwODkxMDE4OTgwLCJleHAiOjE5MTYyNTEwMjEsImlzcyI6ImNvbS5leHBlcml0ZXN0In0.t-LOirn9s-Hs7-TkglyJbsxyK--Usw9KrinjdydkADQ",
        testName: "Demo-Chrome-PayPal Test"
      }
  };

  webdriverio
    .remote(options)
    .init()
    .url('https://paypal.com/us/home')
    .click("//*[@id='menu-button']")
    .getTitle().then(function (title) {
        console.log('Title was: ' + title);
    })
  
    .end()
    .catch(function (err) {
        console.log(err);
    });
  }

main();

"use strict";
var webdriverio = require('webdriverio');

function main() {

  let options = {
    host: 'rbc.experitest.com',
    protocol: 'https',
    port: 443,
    path: '/wd/hub',  
    desiredCapabilities: {
        //accessKey: "<ACCESS_KEY>",
        platformName: 'android',
        browsermName: 'chrome',
        //udid: "R58M3051V9K", 
        accessKey: "eyJhbGciOiJIUzI1NiJ9.eyJ4cC51IjoxMjU0NjIwLCJ4cC5wIjoxMjA3MDA1LCJ4cC5tIjoxNjAwODkxMDE4OTgwLCJleHAiOjE5MTYyNTEwMjEsImlzcyI6ImNvbS5leHBlcml0ZXN0In0.t-LOirn9s-Hs7-TkglyJbsxyK--Usw9KrinjdydkADQ",
        //testName: "Demo-Chrome-Android-PayPal Test"
      }
  };

  webdriverio
    .remote(options)
    .init()
    .url('https://paypal.com/us/home')
    .click("//*[@id='menu-button']")
    .getTitle().then(function (title) {
        console.log('Title was: ' + title);
  
    })
    .end()
    .catch(function (err) {
        console.log(err);
    });
  }

main();
